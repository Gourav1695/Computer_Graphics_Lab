//2. Develop a class 'First' that uses object of another class 'Second' using user defined package 
package PACK1.PACK2;

//here I am using XYZ class for second class
public class Second {
    public void f() {

        System.out.println("In Second,f()");
    }

}


