//4.Develop a program to show inheritance in java using user defined package 
package PACK_D;
import PACK1.PACK2.Second;


public class Second_D extends Second{
    public void fd()
    {
        System.out.println(" In Second_D, fd()");
    }
    public void f()
    {
        System.out. println(" In Second_D, f()");
    }
   

}
