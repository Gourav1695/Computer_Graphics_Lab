//3.Develop a class 'First' that uses object of another class 'Third' using user defined nested package
package PACK1.PACK2.PACK3;

public class Third {
    public  void f22()
    {
        System.out.println("In, Third,f22()");
    }
}
