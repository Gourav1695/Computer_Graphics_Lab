// 5. Develop an applet program using default package
import java.applet.*;
import java.awt.*;

public class firstApplet extends Applet {
    public void init() {
        setBackground(Color.RED);
    }

    public void paint(Graphics g) {

    }

}
