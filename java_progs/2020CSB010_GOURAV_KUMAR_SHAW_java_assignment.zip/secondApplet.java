//6. Develop an applet program using user defined package and user defined nested package(part 1)

package PACK_APL;

import java.applet.*;
import java.awt.*;

public class secondApplet extends Applet {
    // public static void main(String args[]){
    public void init ()
    {
        setBackground(Color.RED);
    }
    public void paint (Graphics g){

    }
}
